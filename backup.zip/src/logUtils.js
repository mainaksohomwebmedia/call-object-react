export function logDailyEvent(e) {
  console.log('[daily.co event]', e.action);
}
